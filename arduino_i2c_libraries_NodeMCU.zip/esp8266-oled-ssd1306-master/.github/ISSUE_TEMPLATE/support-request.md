---
name: Support request
about: Describe this issue template's purpose here.
title: ''
labels: ''
assignees: ''

---

We offer support to our customers at https://support.thingpulse.com/. Send us an email if you don't have an account yet.
